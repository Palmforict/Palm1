/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db123;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "sender")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sender.findAll", query = "SELECT s FROM Sender s"),
    @NamedQuery(name = "Sender.findBySName", query = "SELECT s FROM Sender s WHERE s.sName = :sName"),
    @NamedQuery(name = "Sender.findBySAdderss", query = "SELECT s FROM Sender s WHERE s.sAdderss = :sAdderss"),
    @NamedQuery(name = "Sender.findByCompany", query = "SELECT s FROM Sender s WHERE s.company = :company"),
    @NamedQuery(name = "Sender.findByDeliver", query = "SELECT s FROM Sender s WHERE s.deliver = :deliver"),
    @NamedQuery(name = "Sender.findBySId", query = "SELECT s FROM Sender s WHERE s.sId = :sId")})
public class Sender implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 40)
    @Column(name = "S_Name")
    private String sName;
    @Size(max = 200)
    @Column(name = "S_Adderss")
    private String sAdderss;
    @Size(max = 40)
    @Column(name = "Company")
    private String company;
    @Size(max = 40)
    @Column(name = "Deliver")
    private String deliver;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "S_Id")
    private String sId;
    @OneToMany(mappedBy = "sId")
    private Collection<Deliverdetail> deliverdetailCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sender")
    private Collection<Customer> customerCollection;

    public Sender() {
    }

    public Sender(String sId) {
        this.sId = sId;
    }

    public String getSName() {
        return sName;
    }

    public void setSName(String sName) {
        this.sName = sName;
    }

    public String getSAdderss() {
        return sAdderss;
    }

    public void setSAdderss(String sAdderss) {
        this.sAdderss = sAdderss;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDeliver() {
        return deliver;
    }

    public void setDeliver(String deliver) {
        this.deliver = deliver;
    }

    public String getSId() {
        return sId;
    }

    public void setSId(String sId) {
        this.sId = sId;
    }

    @XmlTransient
    public Collection<Deliverdetail> getDeliverdetailCollection() {
        return deliverdetailCollection;
    }

    public void setDeliverdetailCollection(Collection<Deliverdetail> deliverdetailCollection) {
        this.deliverdetailCollection = deliverdetailCollection;
    }

    @XmlTransient
    public Collection<Customer> getCustomerCollection() {
        return customerCollection;
    }

    public void setCustomerCollection(Collection<Customer> customerCollection) {
        this.customerCollection = customerCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sId != null ? sId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sender)) {
            return false;
        }
        Sender other = (Sender) object;
        if ((this.sId == null && other.sId != null) || (this.sId != null && !this.sId.equals(other.sId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db123.Sender[ sId=" + sId + " ]";
    }
    
}
