/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db123;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "paid")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Paid.findAll", query = "SELECT p FROM Paid p"),
    @NamedQuery(name = "Paid.findByAccountNumber", query = "SELECT p FROM Paid p WHERE p.paidPK.accountNumber = :accountNumber"),
    @NamedQuery(name = "Paid.findByAmount", query = "SELECT p FROM Paid p WHERE p.amount = :amount"),
    @NamedQuery(name = "Paid.findByCId", query = "SELECT p FROM Paid p WHERE p.paidPK.cId = :cId"),
    @NamedQuery(name = "Paid.findBySId", query = "SELECT p FROM Paid p WHERE p.paidPK.sId = :sId")})
public class Paid implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PaidPK paidPK;
    @Size(max = 40)
    @Column(name = "amount")
    private String amount;
    @JoinColumns({
        @JoinColumn(name = "C_Id", referencedColumnName = "C_Id", insertable = false, updatable = false),
        @JoinColumn(name = "S_Id", referencedColumnName = "S_Id", insertable = false, updatable = false)})
    @ManyToOne(optional = false)
    private Customer customer;

    public Paid() {
    }

    public Paid(PaidPK paidPK) {
        this.paidPK = paidPK;
    }

    public Paid(String accountNumber, String cId, String sId) {
        this.paidPK = new PaidPK(accountNumber, cId, sId);
    }

    public PaidPK getPaidPK() {
        return paidPK;
    }

    public void setPaidPK(PaidPK paidPK) {
        this.paidPK = paidPK;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (paidPK != null ? paidPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paid)) {
            return false;
        }
        Paid other = (Paid) object;
        if ((this.paidPK == null && other.paidPK != null) || (this.paidPK != null && !this.paidPK.equals(other.paidPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db123.Paid[ paidPK=" + paidPK + " ]";
    }
    
}
