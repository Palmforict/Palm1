/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db123;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "customer")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Customer.findAll", query = "SELECT c FROM Customer c"),
    @NamedQuery(name = "Customer.findByCName", query = "SELECT c FROM Customer c WHERE c.cName = :cName"),
    @NamedQuery(name = "Customer.findByCProduct", query = "SELECT c FROM Customer c WHERE c.cProduct = :cProduct"),
    @NamedQuery(name = "Customer.findByCAddress", query = "SELECT c FROM Customer c WHERE c.cAddress = :cAddress"),
    @NamedQuery(name = "Customer.findByCId", query = "SELECT c FROM Customer c WHERE c.customerPK.cId = :cId"),
    @NamedQuery(name = "Customer.findBySId", query = "SELECT c FROM Customer c WHERE c.customerPK.sId = :sId")})
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CustomerPK customerPK;
    @Size(max = 40)
    @Column(name = "C_Name")
    private String cName;
    @Size(max = 40)
    @Column(name = "C_Product")
    private String cProduct;
    @Size(max = 200)
    @Column(name = "C_Address")
    private String cAddress;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
    private Collection<Paid> paidCollection;
    @JoinColumn(name = "S_Id", referencedColumnName = "S_Id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Sender sender;

    public Customer() {
    }

    public Customer(CustomerPK customerPK) {
        this.customerPK = customerPK;
    }

    public Customer(String cId, String sId) {
        this.customerPK = new CustomerPK(cId, sId);
    }

    public CustomerPK getCustomerPK() {
        return customerPK;
    }

    public void setCustomerPK(CustomerPK customerPK) {
        this.customerPK = customerPK;
    }

    public String getCName() {
        return cName;
    }

    public void setCName(String cName) {
        this.cName = cName;
    }

    public String getCProduct() {
        return cProduct;
    }

    public void setCProduct(String cProduct) {
        this.cProduct = cProduct;
    }

    public String getCAddress() {
        return cAddress;
    }

    public void setCAddress(String cAddress) {
        this.cAddress = cAddress;
    }

    @XmlTransient
    public Collection<Paid> getPaidCollection() {
        return paidCollection;
    }

    public void setPaidCollection(Collection<Paid> paidCollection) {
        this.paidCollection = paidCollection;
    }

    public Sender getSender() {
        return sender;
    }

    public void setSender(Sender sender) {
        this.sender = sender;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerPK != null ? customerPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.customerPK == null && other.customerPK != null) || (this.customerPK != null && !this.customerPK.equals(other.customerPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db123.Customer[ customerPK=" + customerPK + " ]";
    }
    
}
